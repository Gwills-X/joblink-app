"use client";

import { login } from "@/actions/auth";
import Link from "next/link";
import { useState } from "react";
import useActionState from "@/lib/hooks/useActionState";
import { Eye, EyeOff, Loader2 } from "lucide-react";

export default function Login() {
  const [state, action, isPending] = useActionState(login, undefined);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className='flex min-h-screen flex-col justify-center bg-[var(--color-ink)] py-12 sm:px-6 lg:px-8'>
      <div className='sm:mx-auto sm:w-full sm:max-w-md'>
        <div className='flex items-center justify-center gap-2.5'>
          <div className='flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-500/20 bg-emerald-500/10 font-mono text-sm font-bold text-emerald-400'>
            J
          </div>
          <span className='font-mono text-lg font-semibold tracking-tight text-slate-900 dark:text-slate-100'>
            JobLink
          </span>
        </div>

        <h2 className='mt-6 text-center text-xl font-semibold tracking-tight text-slate-900 dark:text-slate-100'>
          Sign in to your account
        </h2>
        <p className='mt-2 text-center text-sm text-slate-500'>
          Or{" "}
          <Link
            href='/register'
            className='font-medium text-emerald-400 transition-colors duration-150 hover:text-emerald-300'>
            create a free account
          </Link>
        </p>
      </div>

      <div className='mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0'>
        <div className='rounded-xl border border-slate-200 bg-white px-6 py-8 shadow-md sm:px-10 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none'>
          <form action={action} className='space-y-5'>
            {state?.errors?.server && (
              <div className='rounded-lg border border-rose-500/20 bg-rose-500/10 p-3'>
                <p className='text-xs font-medium text-rose-400'>
                  Authentication Error
                </p>
                <p className='mt-1 text-xs text-rose-400/80'>
                  {Array.isArray(state.errors.server)
                    ? state.errors.server[0]
                    : state.errors.server}
                </p>
              </div>
            )}

            <div>
              <label
                htmlFor='email'
                className='mb-1.5 block font-mono text-[11px] font-medium uppercase tracking-wider text-slate-600 dark:text-slate-400'>
                Email Address
              </label>
              <input
                type='email'
                id='email'
                name='email'
                defaultValue={state?.email}
                disabled={isPending}
                required
                className='block w-full rounded-lg border border-slate-300 bg-slate-50 px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 transition-all duration-150 focus:border-emerald-500/50 focus:outline-none focus:ring-1 focus:ring-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100 dark:placeholder:text-slate-600'
                placeholder='name@company.com'
              />
              {state?.errors?.email && (
                <p className='mt-1.5 text-xs font-medium text-rose-400'>
                  {Array.isArray(state.errors.email)
                    ? state.errors.email[0]
                    : state.errors.email}
                </p>
              )}
            </div>

            <div>
              <label
                htmlFor='password'
                className='mb-1.5 block font-mono text-[11px] font-medium uppercase tracking-wider text-slate-600 dark:text-slate-400'>
                Password
              </label>
              <div className='relative'>
                <input
                  type={showPassword ? "text" : "password"}
                  id='password'
                  name='password'
                  disabled={isPending}
                  required
                  className='block w-full rounded-lg border border-slate-300 bg-slate-50 px-3 py-2.5 pr-10 text-sm text-slate-900 placeholder:text-slate-400 transition-all duration-150 focus:border-emerald-500/50 focus:outline-none focus:ring-1 focus:ring-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-100 dark:placeholder:text-slate-600'
                  placeholder='••••••••••••'
                />
                <button
                  type='button'
                  onClick={() => setShowPassword(!showPassword)}
                  className='absolute inset-y-0 right-0 flex items-center px-3 text-slate-500 transition-colors duration-150 hover:text-emerald-400 focus:text-emerald-400 focus:outline-none'
                  aria-label={showPassword ? "Hide password" : "Show password"}>
                  {showPassword ? (
                    <EyeOff className='h-4 w-4' />
                  ) : (
                    <Eye className='h-4 w-4' />
                  )}
                </button>
              </div>
              {state?.errors?.password && (
                <p className='mt-1.5 text-xs font-medium text-rose-400'>
                  {Array.isArray(state.errors.password)
                    ? state.errors.password[0]
                    : state.errors.password}
                </p>
              )}
            </div>

            <div className='pt-1'>
              <button
                type='submit'
                disabled={isPending}
                className='flex w-full items-center justify-center rounded-lg bg-emerald-500 px-4 py-2.5 text-sm font-medium text-[var(--color-slate)] transition-all duration-150 hover:bg-emerald-400 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50'>
                {isPending ? (
                  <span className='flex items-center gap-2'>
                    <Loader2 className='h-4 w-4 animate-spin' />
                    Signing In...
                  </span>
                ) : (
                  "Sign In"
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
